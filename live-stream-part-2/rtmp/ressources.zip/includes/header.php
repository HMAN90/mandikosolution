<nav class="navbar navbar-expand navbar-light bg-white static-top osahan-nav sticky-top">
&nbsp;&nbsp;

<?php if($detect->isMobile()){?>
<button class="btn btn-link btn-sm text-secondary order-1 order-sm-0" type="button" data-trigger="#main_nav">
<i class="fas fa-bars fa-2x text-white"></i>
</button>
<?php }else{?>
<button class="btn btn-link btn-sm text-secondary order-1 order-sm-0 kimpi" id="sidebarToggle" onclick="close__me()">
<i class="fas fa-bars fa-2x text-white"></i>
</button>
<?php } ?>
 &nbsp;&nbsp;
<a class="navbar-brand mr-1" href="index.php">
<img class="img-fluid" src="../img/tv02.png" style="width: 120px">
</a>

<form class="d-none d-md-inline-block form-inline ml-5 mr-0 mr-md-5 my-2 my-md-0 osahan-navbar-search">
<div class="input-group">
<input type="text" class="form-control" placeholder="Search for..." style="border-radius: 0px">
<div class="input-group-append">
<button class="btn btn text-white" type="submit" style="background-color: #ea0c1b;border-radius: 0px">
<i class="fas fa-search"></i>
</button>
</div>
</div>
</form>

<ul class="navbar-nav ml-auto ml-md-0 osahan-right-navbar">
<li class="nav-item mx-1">
<a class="nav-link" style="opacity: 0">
<i class="fa fa-plus-circle fa-fw"></i>
</a>
</li>

<li class="nav-item pull-right" style="position: absolute;right: 170px;">
<a class="icon-socials my-btn-circle" href="https://twitter.com/mandikordc" target="_blank" style="color:#f18c23!important;position: absolute;margin-top: 10px;">
      <i class="bi bi-twitter"></i>
    </a>

    <a class="icon-socials my-btn-circle" href="https://facebook.com/mandikordc" target="_blank" style="color:#f18c23!important;position: absolute;margin-left: 25px;margin-top: 10px;">
      <i class="bi bi-facebook"></i>
    </a>

    <a class="icon-socials my-btn-circle" href="https://instagram.com/mandikoholding" target="_blank" style="color:#f18c23!important;position: absolute;margin-left: 65px;margin-top: 10px;">
      <i class="bi bi-instagram"></i>
    </a>

    <a class="icon-socials my-btn-circle" href="https://www.youtube.com/channel/UChCPbQtfibYX_08ceuVFn_g" target="_blank" style="color:#f18c23!important;position: absolute;margin-left: 105px;margin-top: 10px;">
      <i class="bi bi-youtube"></i>
    </a>
</li>
</ul>
</nav>