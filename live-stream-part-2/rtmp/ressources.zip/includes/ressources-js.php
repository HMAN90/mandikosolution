<script src="vendor/jquery/jquery.min.js" type="31e25fc2350a6746f68ea2c5-text/javascript"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js" type="31e25fc2350a6746f68ea2c5-text/javascript"></script>

<script src="vendor/jquery-easing/jquery.easing.min.js" type="31e25fc2350a6746f68ea2c5-text/javascript"></script>

<script src="vendor/owl-carousel/owl.carousel.js" type="31e25fc2350a6746f68ea2c5-text/javascript"></script>

<script src="js/custom.js" type="31e25fc2350a6746f68ea2c5-text/javascript"></script>
<script src="cloudflare-static/rocket-loader.min.js" data-cf-settings="31e25fc2350a6746f68ea2c5-|49" defer=""></script>

<script type="text/javascript">
	function close__me() {
	  $('.text-link').css('display','none');
	  $('.kimpi').css('display','none');
	  $('.jump').css('display','block');

	}

	function print__me() {
	  $('.text-link').css('display','');
	  $('.kimpi').css('display','block');
	  $('.jump').css('display','none');

	}
</script>