<meta name="theme-color" content="#d3173e">
<link rel="icon" type="image/png" href="../img/man-ico.png">
<link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
<link href="css/osahan.css" rel="stylesheet">
<link rel="stylesheet" href="vendor/owl-carousel/owl.carousel.css">
<link rel="stylesheet" href="vendor/owl-carousel/owl.theme.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
<script src="https://cdn.jwplayer.com/libraries/7TexSdgW.js"></script>

<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>

<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Anton&display=swap" rel="stylesheet">

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">


<?php if($detect->isMobile()){?>
<style type="text/css">
	.modal-dialog {
      width: 100%;
      height: 30vh;
      position:fixed;
	  right:0;
	  left:0;
	  bottom:0;
    }

    .modal-content {
      height: 30vh;
      border-radius: 0;
      position:fixed;
	  right:0;
	  left:0;
	  bottom:0;
    }


</style>
<?php } ?>

<style type="text/css">
	.my-btn-circle {
          height: 30px!important;
          width: 30px!important;
          border-radius: 50%;
          text-align: center;
          vertical-align: middle;
          padding: 7px;
          color: #606060!important;
          background: #ffffff;
          margin-top: 8px;
          position: relative;
          margin-left: -15px;
        }
</style>

<style type="text/css">
	@font-face { font-family: hb; src: url('../typos/helveticaneuebold.ttf');}
         @font-face { font-family: hm; src: url('../typos/helveticaneue-medium.ttf');}
         @font-face { font-family: hl; src: url('../typos/helveticaneuelight.ttf');}
         @font-face { font-family: hr; src: url('../typos/helveticaneue-regular.ttf');}
         @font-face { font-family: book; src: url('../typos/bookman-old-style.ttf');}
         @font-face { font-family: bookb; src: url('../typos/BOOKOSB.TTF');}

         @font-face { font-family: aebb; src: url('../fonts/Anteb-ExtraBlack.ttf');}
         @font-face { font-family: abb; src: url('../fonts/Anteb-Black.ttf');}
         @font-face { font-family: aeb; src: url('../fonts/Anteb-ExtraBold.ttf');}
         @font-face { font-family: ab; src: url('../fonts/Anteb-Bold.ttf');}
         @font-face { font-family: am; src: url('../fonts/Anteb-Medium.ttf');}
         @font-face { font-family: ar; src: url('../fonts/Anteb-Regular.ttf');}
         @font-face { font-family: al; src: url('../fonts/Anteb-Light.ttf');}
         @font-face { font-family: ael; src: url('../fonts/Anteb-ExtraLight.ttf');}
         @font-face { font-family: at; src: url('../fonts/Anteb-Thin.ttf');}


         @font-face { font-family: latobb; src: url('../fonts/Lato-Black.ttf');}
         @font-face { font-family: latob; src: url('../fonts/Lato-Bold.ttf');}
         @font-face { font-family: latoh; src: url('../fonts/Lato-Heavy.ttf');}
         @font-face { font-family: latosb; src: url('../fonts/Lato-Semibold.ttf');}
         @font-face { font-family: latom; src: url('../fonts/Lato-Medium.ttf');}
         @font-face { font-family: lator; src: url('../fonts/Lato-Regular.ttf');}
         @font-face { font-family: latol; src: url('../fonts/Lato-Light.ttf');}
         @font-face { font-family: latot; src: url('../fonts/Lato-Thin.ttf');}
         @font-face { font-family: latoha; src: url('../fonts/Lato-Hairline.ttf');}
</style>