<?php if($detect->isMobile()){?>

<!-- <div class="toggled">

</div> -->


<style type="text/css">
.offcanvas-header{ display:none; }

@media (max-width: 992px) {
  .offcanvas-header{ display:block; }
  .navbar-collapse {
    position: fixed;
    top:0; 
    bottom: 0;
    left: 100%;
    width: 100%;
    padding-right: 1rem;
    padding-left: 1rem;
    overflow-y: auto;
    z-index: 999999999999;
    visibility: hidden;
    background-color:#232323!important;
    transition: visibility .2s ease-in-out, -webkit-transform .2s ease-in-out;
  }
  .navbar-collapse.show {
    visibility: visible;
    transform: translateX(-100%);
  }
}
.link-item{
	font-size:1.6em;
	font-family:Anton;
	font-weight: 300;
	color: #ffffff;
	text-transform:;
}
</style>

<!--   <a class="navbar-brand" href="#">Navbar</a>
  <button class="navbar-toggler" type="button" data-trigger="#main_nav">
    <span class="navbar-toggler-icon"></span>
  </button> -->
  <div class="navbar-collapse" id="main_nav">
    <div class="offcanvas-header mt-3">  
      <button class="btn btn btn-close btn-sm float-right mt-2" style="background-color: rgba(0,0,0,0);color: #ffffff;border-radius: 0px">
      	<i class="fas fa-times-circle fa-lg"></i> Fermer
      </button>
      <a class="navbar-brand mr-1" href="index.php">
		<img class="img-fluid" src="img/logo-likyantv.png" style="width: 120px">
		</a>
    </div>

    <form class="d-md-inline-block form-inline mt-5 mb-4 mr-0 my-2 my-md-0 osahan-navbar-search" style="width: 100%">
	<div class="input-group">
	<input type="text" class="form-control" placeholder="Search for..." style="border-radius: 0px">
	<div class="input-group-append">
	<button class="btn btn text-white" type="submit" style="background-color: #d3173e;border-radius: 0px">
	<i class="fas fa-search"></i>
	</button>
	</div>
	</div>
	</form>
    <ul class="navbar-nav">
      <li class="nav-item active toggled">
      	<a class="nav-link link-item" href="index.php" style="font-family: hb!important;">Direct </a>
      </li>
      <!-- <li class="nav-item">
      	<a class="nav-link link-item" href="#" style="font-family: hb!important;"> S'abonner </a>
      </li> -->
      <li class="nav-item">
      	<a class="nav-link link-item" href="#" style="font-family: hb!important;"> Mes Tickets </a>
      </li>

      <!-- <li class="nav-item">
      	<a class="nav-link link-item" href="categories.php" style="font-family: hb!important;"> Categories </a>
      </li> -->

      <li class="nav-item">
      	<a class="nav-link link-item" href="#" style="font-family: hb!important;">Nos Programmes </a>
      </li>

      <li class="nav-item">
      	<a class="nav-link link-item" href="#" style="font-family: hb!important;"> A propos </a>
      </li>

      <li class="nav-item">
      	<a class="nav-link link-item" href="#" style="font-family: hb!important;"> Contact </a>
      </li>

      <li class="nav-item">
      	<a class="nav-link link-item" href="#" style="font-family: hb!important;"> Aide </a>
      </li>

    </ul>
  </div> <!-- navbar-collapse.// -->

<script type="text/javascript">
$("[data-trigger]").on("click", function(){
    var trigger_id =  $(this).attr('data-trigger');
    $(trigger_id).toggleClass("show");
    $('body').toggleClass("offcanvas-active");
});

// close button 
$(".btn-close").click(function(e){
    $(".navbar-collapse").removeClass("show");
    $("body").removeClass("offcanvas-active");
}); 

</script>
<?php }else{?>

<ul class="sidebar navbar-nav">
<li class="nav-item active">
<a class="nav-link" href="index.php">
<i class="fas fa-fw fa-circle animate__animated animate__pulse animate__infinite" style="color: #d3173e"></i>
<span class="text-link" style="font-family: hb!important;">DIRECT</span>
</a>
</li>
<!-- <li class="nav-item">
<a class="nav-link" href="abonnement.php">
<i class="fas fa-fw fa-chalkboard-teacher"></i>
<span class="text-link" style="font-family: hb!important;">S'ABONNER</span>
</a>
</li> -->
<li class="nav-item">
<a class="nav-link" href="#!">
<i class="fas fa-fw fa-box-open"></i>
<span class="text-link" style="font-family: hb!important;">TICKETS STREAM</span>
</a>
</li>

<!-- <li class="nav-item dropdown">
<a class="nav-link dropdown-toggle" href="categories.html" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
<i class="fas fa-fw fa-list-alt"></i>
<span>CATEGORIES</span>
</a>
<div class="dropdown-menu">
<a class="dropdown-item" href="categories.html">Movie</a>
<a class="dropdown-item" href="categories.html">Music</a>
<a class="dropdown-item" href="categories.html">Television</a>
</div>
</li> -->

<!-- <li class="nav-item">
<a class="nav-link" href="categories.php">
<i class="fas fa-fw fa-list-alt"></i>
<span class="text-link" style="font-family: hb!important;"></span>
</a>
</li> -->

<li class="nav-item">
<a class="nav-link" href="#!">
<i class="fas fa-fw fa-cog"></i>
<span class="text-link" style="font-family: hb!important;">NOS PROGRAMMES</span>
</a>
</li>

<li class="nav-item">
<a class="nav-link" href="#!">
<i class="fas fa-fw fa-info-circle"></i>
<span class="text-link" style="font-family: hb!important;">A PROPOS</span>
</a>
</li>

<li class="nav-item">
<a class="nav-link" href="#!">
<i class="fas fa-fw fa-phone"></i>
<span class="text-link" style="font-family: hb!important;">CONTACT</span>
</a>
</li>

<li class="nav-item">
<a class="nav-link" href="#!">
<i class="fas fa-fw fa-question-circle"></i>
<span class="text-link" style="font-family: hb!important;">AIDE</span>
</a>
</li>

<li class="nav-item channel-sidebar-list">
<h6 style="font-family: hb!important;">NOS EMISSIONS</h6>
<ul>
<li>
<a href="#!">
<img class="img-fluid" alt="" src="../emissions/3.png"> Digi Tech
</a>
</li>
<li>
<a href="#!">
<img class="img-fluid" alt="" src="../emissions/2.png"> 5 min avec moi <span class="badge badge-warning">En direct</span>
</a>
</li>
<li>
<a href="#!">
<img class="img-fluid" alt="" src="../emissions/9.png"> Opinions des dames
</a>
</li>
<li>
<a href="#!" class="mb-4">
<img class="img-fluid" alt="" src="../emissions/6.png"> Mandiko Day
</a>
</li>
</ul>
</li>
</ul>

<?php } ?>
<!-- modal confirm -->

<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
<div class="modal-dialog modal-sm modal-dialog-centered" role="document">
<div class="modal-content">
<div class="modal-header border-0">
<h5 class="modal-title" id="exampleModalLabel">Déconnexion</h5>
<button class="close" type="button" data-dismiss="modal" aria-label="Close">
<span aria-hidden="true">×</span>
</button>
</div>
<div class="modal-body">Voulez-vous vraiment vous déconnecter?</div>
<div class="modal-footer border-0">
<button class="btn btn-secondary btn-sm" type="button" data-dismiss="modal" style="border-radius: 0px">ANNULER</button>
<a class="btn btn-primary btn-sm" href="login.php" style="border-radius: 0px">LOGOUT</a>
</div>
</div>
</div>
</div>